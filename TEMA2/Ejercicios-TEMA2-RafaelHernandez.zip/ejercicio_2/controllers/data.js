
var nombres = ["Mario", "Patricia", "Manolo", "Santi", "David", "Oscar", "Luis", "Saul", "Autor"];

var getNames = function() {
	return nombres;
}

module.exports = {
	getNames: getNames
}